"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { CreditCard, Edit2, User } from "lucide-react"

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)

  // Mock user data
  const user = {
    id: "user-1001",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    address: "123 Main St, Anytown, CA 12345",
    skyMiles: 12500,
    memberSince: "January 2022",
    tier: "Silver",
    paymentMethods: [
      {
        id: "pm-1",
        type: "Visa",
        last4: "4242",
        expiry: "05/25",
        isDefault: true,
      },
      {
        id: "pm-2",
        type: "Mastercard",
        last4: "5555",
        expiry: "08/26",
        isDefault: false,
      },
    ],
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">My Profile</h1>
        <p className="text-muted-foreground">Manage your account information and preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <User className="h-12 w-12 text-primary" />
                </div>
                <h2 className="text-xl font-bold">
                  {user.firstName} {user.lastName}
                </h2>
                <p className="text-muted-foreground mb-2">{user.email}</p>
                <div className="flex items-center justify-center mb-4">
                  <Badge variant="secondary">{user.tier} Member</Badge>
                </div>
                <div className="w-full bg-muted rounded-full h-4 mb-2">
                  <div className="bg-primary h-4 rounded-full" style={{ width: "45%" }}></div>
                </div>
                <p className="text-sm text-muted-foreground mb-6">5,500 miles to Gold status</p>
                <Button variant="outline" className="w-full" asChild>
                  <a href="/my-bookings">View My Bookings</a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="personal" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="personal">Personal Info</TabsTrigger>
              <TabsTrigger value="payment">Payment Methods</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
            </TabsList>

            <TabsContent value="personal">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>Manage your personal details</CardDescription>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => setIsEditing(!isEditing)}>
                    <Edit2 className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" defaultValue={user.firstName} disabled={!isEditing} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" defaultValue={user.lastName} disabled={!isEditing} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input id="email" type="email" defaultValue={user.email} disabled={!isEditing} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" defaultValue={user.phone} disabled={!isEditing} />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">Address</Label>
                      <Input id="address" defaultValue={user.address} disabled={!isEditing} />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className={isEditing ? "flex justify-end gap-2" : "hidden"}>
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                  <Button>Save Changes</Button>
                </CardFooter>
              </Card>

              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>SkyMiles Information</CardTitle>
                  <CardDescription>Your loyalty program details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">Member Since</h3>
                        <p className="font-medium">{user.memberSince}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">SkyMiles Number</h3>
                        <p className="font-medium">SM{user.id.slice(-8)}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">Current Tier</h3>
                        <p className="font-medium">{user.tier}</p>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-3">SkyMiles Balance</h3>
                      <div className="flex items-center">
                        <div className="text-3xl font-bold mr-2">{user.skyMiles.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">miles</div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-3">Miles Activity</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">Flight: JFK to LAX</p>
                            <p className="text-sm text-muted-foreground">May 5, 2024</p>
                          </div>
                          <div className="text-green-600">+2,500 miles</div>
                        </div>
                        <Separator />
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">Flight: LAX to JFK</p>
                            <p className="text-sm text-muted-foreground">April 28, 2024</p>
                          </div>
                          <div className="text-green-600">+2,500 miles</div>
                        </div>
                        <Separator />
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">Miles Redemption: Hotel Stay</p>
                            <p className="text-sm text-muted-foreground">April 15, 2024</p>
                          </div>
                          <div className="text-red-600">-5,000 miles</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment">
              <Card>
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                  <CardDescription>Manage your saved payment methods</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {user.paymentMethods.map((method) => (
                      <div key={method.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                            <CreditCard className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">
                              {method.type} •••• {method.last4}
                            </p>
                            <p className="text-sm text-muted-foreground">Expires {method.expiry}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {method.isDefault && <Badge variant="outline">Default</Badge>}
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                            Remove
                          </Button>
                        </div>
                      </div>
                    ))}

                    <Button className="w-full">Add New Payment Method</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Travel Preferences</CardTitle>
                  <CardDescription>Customize your travel experience</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="seatPreference">Seat Preference</Label>
                      <Select defaultValue="window">
                        <SelectTrigger id="seatPreference">
                          <SelectValue placeholder="Select preference" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="window">Window</SelectItem>
                          <SelectItem value="aisle">Aisle</SelectItem>
                          <SelectItem value="middle">Middle</SelectItem>
                          <SelectItem value="no-preference">No Preference</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="mealPreference">Meal Preference</Label>
                      <Select defaultValue="regular">
                        <SelectTrigger id="mealPreference">
                          <SelectValue placeholder="Select preference" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="regular">Regular</SelectItem>
                          <SelectItem value="vegetarian">Vegetarian</SelectItem>
                          <SelectItem value="vegan">Vegan</SelectItem>
                          <SelectItem value="kosher">Kosher</SelectItem>
                          <SelectItem value="halal">Halal</SelectItem>
                          <SelectItem value="diabetic">Diabetic</SelectItem>
                          <SelectItem value="gluten-free">Gluten Free</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="frequentFlyerPrograms">Frequent Flyer Programs</Label>
                      <Select defaultValue="skymiles">
                        <SelectTrigger id="frequentFlyerPrograms">
                          <SelectValue placeholder="Select program" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="skymiles">SkyMiles</SelectItem>
                          <SelectItem value="aadvantage">AAdvantage</SelectItem>
                          <SelectItem value="mileageplus">MileagePlus</SelectItem>
                          <SelectItem value="skywards">Skywards</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Communication Preferences</Label>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="emailNotifications" className="cursor-pointer">
                            Email Notifications
                          </Label>
                          <input type="checkbox" id="emailNotifications" defaultChecked className="toggle" />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="smsNotifications" className="cursor-pointer">
                            SMS Notifications
                          </Label>
                          <input type="checkbox" id="smsNotifications" defaultChecked className="toggle" />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="promotionalEmails" className="cursor-pointer">
                            Promotional Emails
                          </Label>
                          <input type="checkbox" id="promotionalEmails" className="toggle" />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="ml-auto">Save Preferences</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
