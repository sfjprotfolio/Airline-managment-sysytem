import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Clock, Plane } from "lucide-react"

export default function SearchResults() {
  // Mock data for demonstration
  const flights = [
    {
      id: "fl-1001",
      flightNumber: "AA123",
      origin: "New York (JFK)",
      destination: "Los Angeles (LAX)",
      departureTime: "08:00 AM",
      arrivalTime: "11:30 AM",
      duration: "5h 30m",
      price: 299,
      stops: 0,
      airline: "American Airlines",
      aircraft: "Boeing 787",
      availableSeats: 24,
    },
    {
      id: "fl-1002",
      flightNumber: "DL456",
      origin: "New York (JFK)",
      destination: "Los Angeles (LAX)",
      departureTime: "10:15 AM",
      arrivalTime: "01:45 PM",
      duration: "5h 30m",
      price: 275,
      stops: 0,
      airline: "Delta Airlines",
      aircraft: "Airbus A321",
      availableSeats: 12,
    },
    {
      id: "fl-1003",
      flightNumber: "UA789",
      origin: "New York (JFK)",
      destination: "Los Angeles (LAX)",
      departureTime: "02:30 PM",
      arrivalTime: "08:15 PM",
      duration: "5h 45m",
      price: 325,
      stops: 1,
      stopCity: "Chicago (ORD)",
      airline: "United Airlines",
      aircraft: "Boeing 737",
      availableSeats: 8,
    },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Flight Search Results</h1>
        <p className="text-muted-foreground">New York (JFK) to Los Angeles (LAX) · May 15, 2024 · 1 Adult · Economy</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Filter Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium mb-2">Price Range</h3>
                <div className="flex items-center">
                  <input type="range" min="100" max="1000" className="w-full" />
                </div>
                <div className="flex justify-between mt-2">
                  <span>$100</span>
                  <span>$1000</span>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Stops</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="nonstop" className="mr-2" defaultChecked />
                    <label htmlFor="nonstop">Non-stop</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="1stop" className="mr-2" defaultChecked />
                    <label htmlFor="1stop">1 Stop</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="2stops" className="mr-2" />
                    <label htmlFor="2stops">2+ Stops</label>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Airlines</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="aa" className="mr-2" defaultChecked />
                    <label htmlFor="aa">American Airlines</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="dl" className="mr-2" defaultChecked />
                    <label htmlFor="dl">Delta Airlines</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="ua" className="mr-2" defaultChecked />
                    <label htmlFor="ua">United Airlines</label>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Departure Time</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="morning" className="mr-2" defaultChecked />
                    <label htmlFor="morning">Morning (5:00 AM - 11:59 AM)</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="afternoon" className="mr-2" defaultChecked />
                    <label htmlFor="afternoon">Afternoon (12:00 PM - 5:59 PM)</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="evening" className="mr-2" defaultChecked />
                    <label htmlFor="evening">Evening (6:00 PM - 11:59 PM)</label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="best" className="w-full mb-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="best">Best</TabsTrigger>
              <TabsTrigger value="cheapest">Cheapest</TabsTrigger>
              <TabsTrigger value="fastest">Fastest</TabsTrigger>
              <TabsTrigger value="earliest">Earliest</TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="space-y-4">
            {flights.map((flight) => (
              <Card key={flight.id} className="overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-3">
                  <div className="md:col-span-2 p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mr-4">
                        <Plane className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{flight.airline}</h3>
                        <p className="text-sm text-muted-foreground">
                          Flight {flight.flightNumber} · {flight.aircraft}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold">{flight.departureTime}</p>
                        <p className="text-sm text-muted-foreground">{flight.origin}</p>
                      </div>

                      <div className="flex flex-col items-center my-2 md:my-0">
                        <p className="text-sm text-muted-foreground flex items-center">
                          <Clock className="h-4 w-4 mr-1" /> {flight.duration}
                        </p>
                        <div className="relative w-32 md:w-40 h-[2px] bg-muted my-2">
                          <div className="absolute top-1/2 left-0 w-2 h-2 bg-primary rounded-full transform -translate-y-1/2"></div>
                          {flight.stops > 0 && (
                            <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-primary rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
                          )}
                          <div className="absolute top-1/2 right-0 w-2 h-2 bg-primary rounded-full transform -translate-y-1/2"></div>
                        </div>
                        {flight.stops === 0 ? (
                          <p className="text-xs">Non-stop</p>
                        ) : (
                          <p className="text-xs">
                            {flight.stops} stop ({flight.stopCity})
                          </p>
                        )}
                      </div>

                      <div className="text-center">
                        <p className="text-2xl font-bold">{flight.arrivalTime}</p>
                        <p className="text-sm text-muted-foreground">{flight.destination}</p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <Badge variant="outline" className="mr-2">
                        {flight.availableSeats} seats left
                      </Badge>
                      {flight.stops === 0 && <Badge variant="secondary">Direct Flight</Badge>}
                    </div>
                  </div>

                  <div className="bg-muted/20 p-6 flex flex-col justify-between border-t md:border-t-0 md:border-l">
                    <div>
                      <p className="text-3xl font-bold mb-1">${flight.price}</p>
                      <p className="text-sm text-muted-foreground mb-4">per passenger</p>
                    </div>
                    <Button asChild className="w-full">
                      <Link href={`/booking/${flight.id}`}>
                        Select <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
