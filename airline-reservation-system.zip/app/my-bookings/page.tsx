"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Clock } from "lucide-react"
import { cn } from "@/lib/utils"

export default function MyBookings() {
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [showCancelDialog, setShowCancelDialog] = useState(false)
  const [showRescheduleDialog, setShowRescheduleDialog] = useState(false)

  // Mock booking data
  const bookings = [
    {
      id: "bk-1001",
      confirmationNumber: "CNF12345678",
      type: "confirmed",
      flightNumber: "AA123",
      origin: "New York (JFK)",
      destination: "Los Angeles (LAX)",
      departureDate: "May 15, 2024",
      departureTime: "08:00 AM",
      arrivalTime: "11:30 AM",
      passengers: 1,
      price: 359.0,
    },
    {
      id: "bk-1002",
      confirmationNumber: "BLK87654321",
      type: "blocked",
      flightNumber: "DL456",
      origin: "Los Angeles (LAX)",
      destination: "New York (JFK)",
      departureDate: "June 22, 2024",
      departureTime: "10:15 AM",
      arrivalTime: "06:45 PM",
      passengers: 2,
      price: 578.0,
    },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">My Bookings</h1>
        <p className="text-muted-foreground">Manage your flight reservations</p>
      </div>

      <Tabs defaultValue="upcoming" className="w-full mb-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="mt-6">
          <div className="space-y-6">
            {bookings.map((booking) => (
              <Card key={booking.id}>
                <CardHeader className="pb-2">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <CardTitle className="text-xl">
                        {booking.origin} to {booking.destination}
                      </CardTitle>
                      <CardDescription>{booking.departureDate}</CardDescription>
                    </div>
                    <Badge
                      className={cn(
                        "mt-2 md:mt-0",
                        booking.type === "confirmed"
                          ? "bg-green-100 text-green-800 hover:bg-green-100"
                          : "bg-blue-100 text-blue-800 hover:bg-blue-100",
                      )}
                    >
                      {booking.type === "confirmed" ? "Confirmed" : "Blocked"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">Flight Details</h3>
                      <p className="font-medium">{booking.flightNumber}</p>
                      <div className="flex items-center mt-1">
                        <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span className="text-sm">
                          {booking.departureTime} - {booking.arrivalTime}
                        </span>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">Confirmation Number</h3>
                      <p className="font-medium">{booking.confirmationNumber}</p>
                      <p className="text-sm mt-1">
                        {booking.passengers} Passenger{booking.passengers > 1 ? "s" : ""}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">Price</h3>
                      <p className="font-medium">${booking.price.toFixed(2)}</p>
                      {booking.type === "blocked" && (
                        <p className="text-sm text-blue-600 mt-1">Payment due by June 8, 2024</p>
                      )}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-wrap gap-2">
                  <Button variant="outline" asChild>
                    <Link href={`/booking-details/${booking.id}`}>View Details</Link>
                  </Button>

                  {booking.type === "blocked" && <Button>Confirm Booking</Button>}

                  <Button variant="outline" onClick={() => setShowRescheduleDialog(true)}>
                    Reschedule
                  </Button>

                  <Button
                    variant="outline"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => setShowCancelDialog(true)}
                  >
                    Cancel
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="past">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium mb-2">No past bookings found</h3>
            <p className="text-muted-foreground mb-6">Your completed trips will appear here</p>
            <Button asChild>
              <Link href="/search">Book a New Flight</Link>
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="cancelled">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium mb-2">No cancelled bookings found</h3>
            <p className="text-muted-foreground mb-6">Your cancelled bookings will appear here</p>
            <Button asChild>
              <Link href="/search">Book a New Flight</Link>
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Cancel Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Booking</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this booking? Please review the cancellation policy below before
              proceeding.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Cancellation Policy</h4>
              <ul className="text-sm space-y-1">
                <li>• Free cancellation up to 7 days before departure</li>
                <li>• 50% refund between 7 days and 48 hours before departure</li>
                <li>• No refund within 48 hours of departure</li>
              </ul>
            </div>
            <p>
              Based on your booking date, you will receive a <strong>100% refund</strong> of your booking amount.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
              Keep Booking
            </Button>
            <Button variant="destructive">Confirm Cancellation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reschedule Dialog */}
      <Dialog open={showRescheduleDialog} onOpenChange={setShowRescheduleDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reschedule Flight</DialogTitle>
            <DialogDescription>
              Select a new date for your flight. Available flights will be shown based on your selection.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h4 className="font-medium">New Departure Date</h4>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : <span>Select date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    initialFocus
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Rescheduling Policy</h4>
              <ul className="text-sm space-y-1">
                <li>• Free rescheduling up to 7 days before departure</li>
                <li>• $50 fee between 7 days and 48 hours before departure</li>
                <li>• $100 fee within 48 hours of departure</li>
                <li>• Any fare difference will be charged or refunded</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRescheduleDialog(false)}>
              Cancel
            </Button>
            <Button disabled={!selectedDate}>Find Available Flights</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
