import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import Link from "next/link"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Airline Reservation System",
  description: "A comprehensive airline reservation system",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <div className="flex min-h-screen flex-col">
            <header className="sticky top-0 z-40 w-full border-b bg-background">
              <div className="container flex h-16 items-center justify-between py-4">
                <div className="flex items-center gap-6 md:gap-10">
                  <Link href="/" className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"></path>
                    </svg>
                    <span className="hidden font-bold sm:inline-block">AirlineRS</span>
                  </Link>
                  <MainNav />
                </div>
                <div className="flex items-center gap-4">
                  <UserNav />
                </div>
              </div>
            </header>
            <main className="flex-1">{children}</main>
            <footer className="border-t bg-muted">
              <div className="container py-8 px-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  <div>
                    <h3 className="font-semibold mb-4">About Us</h3>
                    <ul className="space-y-2 text-sm">
                      <li>
                        <Link href="/about" className="hover:underline">
                          Company
                        </Link>
                      </li>
                      <li>
                        <Link href="/careers" className="hover:underline">
                          Careers
                        </Link>
                      </li>
                      <li>
                        <Link href="/press" className="hover:underline">
                          Press
                        </Link>
                      </li>
                      <li>
                        <Link href="/partners" className="hover:underline">
                          Partners
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Help</h3>
                    <ul className="space-y-2 text-sm">
                      <li>
                        <Link href="/faq" className="hover:underline">
                          FAQ
                        </Link>
                      </li>
                      <li>
                        <Link href="/contact" className="hover:underline">
                          Contact Us
                        </Link>
                      </li>
                      <li>
                        <Link href="/baggage" className="hover:underline">
                          Baggage
                        </Link>
                      </li>
                      <li>
                        <Link href="/refunds" className="hover:underline">
                          Refunds
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Legal</h3>
                    <ul className="space-y-2 text-sm">
                      <li>
                        <Link href="/terms" className="hover:underline">
                          Terms & Conditions
                        </Link>
                      </li>
                      <li>
                        <Link href="/privacy" className="hover:underline">
                          Privacy Policy
                        </Link>
                      </li>
                      <li>
                        <Link href="/cookies" className="hover:underline">
                          Cookie Policy
                        </Link>
                      </li>
                      <li>
                        <Link href="/accessibility" className="hover:underline">
                          Accessibility
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Connect With Us</h3>
                    <div className="flex space-x-4 mb-4">
                      <a href="#" className="text-muted-foreground hover:text-foreground">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                        </svg>
                        <span className="sr-only">Facebook</span>
                      </a>
                      <a href="#" className="text-muted-foreground hover:text-foreground">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                        </svg>
                        <span className="sr-only">Instagram</span>
                      </a>
                      <a href="#" className="text-muted-foreground hover:text-foreground">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                        </svg>
                        <span className="sr-only">Twitter</span>
                      </a>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Subscribe to our newsletter for the latest updates and offers.
                    </p>
                    <div className="mt-2 flex">
                      <input
                        type="email"
                        placeholder="Your email"
                        className="flex-1 rounded-l-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                      />
                      <button className="rounded-r-md border border-primary bg-primary px-3 py-2 text-sm font-medium text-primary-foreground">
                        Subscribe
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
                  <p>© {new Date().getFullYear()} AirlineRS. All rights reserved.</p>
                </div>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
