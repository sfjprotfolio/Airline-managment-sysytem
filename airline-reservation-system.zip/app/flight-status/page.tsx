"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Plane, ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

export default function FlightStatusPage() {
  const [date, setDate] = useState<Date>()
  const [showResults, setShowResults] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setShowResults(true)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Flight Status</h1>
        <p className="text-muted-foreground">Check the status of any flight</p>
      </div>

      <Card className="max-w-3xl mx-auto mb-8">
        <CardHeader>
          <CardTitle>Search Flight Status</CardTitle>
          <CardDescription>Enter flight details to check status</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="flight" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="flight">By Flight Number</TabsTrigger>
              <TabsTrigger value="route">By Route</TabsTrigger>
            </TabsList>
            <TabsContent value="flight">
              <form onSubmit={handleSearch} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="flightNumber">Flight Number</Label>
                    <Input id="flightNumber" placeholder="e.g. AA123" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant={"outline"}
                          className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, "PPP") : <span>Select date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                <Button type="submit" className="w-full">
                  Check Status
                </Button>
              </form>
            </TabsContent>
            <TabsContent value="route">
              <form onSubmit={handleSearch} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="origin">From</Label>
                    <Input id="origin" placeholder="City or Airport" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="destination">To</Label>
                    <Input id="destination" placeholder="City or Airport" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Select date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>
                <Button type="submit" className="w-full">
                  Check Status
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {showResults && (
        <div className="space-y-6 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold">Flight Status Results</h2>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <Plane className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">AA123</h3>
                  <p className="text-sm text-muted-foreground">American Airlines • Boeing 787</p>
                </div>
                <div className="ml-auto">
                  <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold bg-green-100 text-green-800 border-green-200">
                    On Time
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Departure</p>
                  <p className="text-2xl font-bold">08:00 AM</p>
                  <p className="font-medium">New York (JFK)</p>
                  <p className="text-sm text-muted-foreground">Terminal 8, Gate A12</p>
                  <p className="text-sm text-green-600 font-medium mt-2">On Time</p>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <div className="text-sm text-muted-foreground mb-2">5h 30m</div>
                  <div className="relative w-full h-[2px] bg-muted">
                    <div className="absolute top-1/2 left-0 w-2 h-2 bg-primary rounded-full transform -translate-y-1/2"></div>
                    <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-primary rounded-full transform -translate-x-1/2 -translate-y-1/2 animate-pulse"></div>
                    <div className="absolute top-1/2 right-0 w-2 h-2 bg-primary rounded-full transform -translate-y-1/2"></div>
                  </div>
                  <div className="flex justify-between w-full mt-2">
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    <p className="text-xs text-muted-foreground">Non-stop</p>
                  </div>
                </div>

                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Arrival</p>
                  <p className="text-2xl font-bold">11:30 AM</p>
                  <p className="font-medium">Los Angeles (LAX)</p>
                  <p className="text-sm text-muted-foreground">Terminal 4, Gate B8</p>
                  <p className="text-sm text-green-600 font-medium mt-2">On Time</p>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="font-medium mb-1">Flight Date</p>
                  <p>May 15, 2024</p>
                </div>
                <div>
                  <p className="font-medium mb-1">Aircraft</p>
                  <p>Boeing 787-9 Dreamliner</p>
                </div>
                <div>
                  <p className="font-medium mb-1">Status</p>
                  <p className="text-green-600">Scheduled</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="bg-muted p-4 rounded-lg">
            <h3 className="font-medium mb-2">Flight Information</h3>
            <p className="text-sm mb-4">This information is updated in real-time. Last updated: 10:15 AM EDT</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium">Baggage Claim</p>
                <p>Carousel 5 (LAX Terminal 4)</p>
              </div>
              <div>
                <p className="font-medium">Weather at Destination</p>
                <p>75°F, Sunny</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
