"use client"

import { useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { ArrowLeft, Check, CreditCard, Info, Plane, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function BookingPage() {
  const params = useParams()
  const flightId = params.id

  // Mock flight data based on ID
  const flight = {
    id: flightId,
    flightNumber: "AA123",
    origin: "New York (JFK)",
    destination: "Los Angeles (LAX)",
    departureDate: "May 15, 2024",
    departureTime: "08:00 AM",
    arrivalTime: "11:30 AM",
    duration: "5h 30m",
    price: 299,
    stops: 0,
    airline: "American Airlines",
    aircraft: "Boeing 787",
  }

  const [bookingStep, setBookingStep] = useState<"details" | "payment" | "confirmation">("details")
  const [bookingType, setBookingType] = useState<"buy" | "block">("buy")

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <Link href="/search-results" className="flex items-center text-primary mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to search results
        </Link>
        <h1 className="text-3xl font-bold mb-2">Complete Your Booking</h1>
        <p className="text-muted-foreground">
          Flight {flight.flightNumber} · {flight.origin} to {flight.destination} · {flight.departureDate}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <Plane className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>Flight Details</CardTitle>
                  <CardDescription>Review your flight information</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                <div className="text-center">
                  <p className="text-2xl font-bold">{flight.departureTime}</p>
                  <p className="text-sm text-muted-foreground">{flight.origin}</p>
                  <p className="text-xs text-muted-foreground">{flight.departureDate}</p>
                </div>

                <div className="flex flex-col items-center my-4 md:my-0">
                  <p className="text-sm text-muted-foreground">{flight.duration}</p>
                  <div className="relative w-32 md:w-40 h-[2px] bg-muted my-2">
                    <div className="absolute top-1/2 left-0 w-2 h-2 bg-primary rounded-full transform -translate-y-1/2"></div>
                    <div className="absolute top-1/2 right-0 w-2 h-2 bg-primary rounded-full transform -translate-y-1/2"></div>
                  </div>
                  <p className="text-xs">Non-stop</p>
                </div>

                <div className="text-center">
                  <p className="text-2xl font-bold">{flight.arrivalTime}</p>
                  <p className="text-sm text-muted-foreground">{flight.destination}</p>
                  <p className="text-xs text-muted-foreground">{flight.departureDate}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 text-sm">
                <div>
                  <span className="font-medium">Airline:</span> {flight.airline}
                </div>
                <div>
                  <span className="font-medium">Flight:</span> {flight.flightNumber}
                </div>
                <div>
                  <span className="font-medium">Aircraft:</span> {flight.aircraft}
                </div>
                <div>
                  <span className="font-medium">Class:</span> Economy
                </div>
              </div>
            </CardContent>
          </Card>

          {bookingStep === "details" && (
            <>
              <Card className="mb-6">
                <CardHeader>
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle>Passenger Information</CardTitle>
                      <CardDescription>Enter details for all passengers</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium mb-4">Passenger 1 (Adult)</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="firstName">First Name</Label>
                          <Input id="firstName" placeholder="Enter first name" />
                        </div>
                        <div>
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input id="lastName" placeholder="Enter last name" />
                        </div>
                        <div>
                          <Label htmlFor="dob">Date of Birth</Label>
                          <Input id="dob" type="date" />
                        </div>
                        <div>
                          <Label htmlFor="gender">Gender</Label>
                          <Select>
                            <SelectTrigger id="gender">
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="male">Male</SelectItem>
                              <SelectItem value="female">Female</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="passport">Passport Number</Label>
                          <Input id="passport" placeholder="Enter passport number" />
                        </div>
                        <div>
                          <Label htmlFor="nationality">Nationality</Label>
                          <Select>
                            <SelectTrigger id="nationality">
                              <SelectValue placeholder="Select country" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="us">United States</SelectItem>
                              <SelectItem value="ca">Canada</SelectItem>
                              <SelectItem value="uk">United Kingdom</SelectItem>
                              <SelectItem value="au">Australia</SelectItem>
                              {/* More countries would be added here */}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium mb-4">Contact Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="email">Email Address</Label>
                          <Input id="email" type="email" placeholder="Enter email address" />
                        </div>
                        <div>
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input id="phone" placeholder="Enter phone number" />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="w-full">
                    <Alert className="mb-4">
                      <Info className="h-4 w-4" />
                      <AlertTitle>Booking Options</AlertTitle>
                      <AlertDescription>
                        You can choose to buy the ticket now or block it for up to 2 weeks before the departure date at
                        no cost.
                      </AlertDescription>
                    </Alert>

                    <RadioGroup
                      defaultValue="buy"
                      className="mb-4"
                      onValueChange={(value) => setBookingType(value as "buy" | "block")}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="buy" id="buy" />
                        <Label htmlFor="buy">Buy ticket now</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="block" id="block" />
                        <Label htmlFor="block">Block ticket (confirm later)</Label>
                      </div>
                    </RadioGroup>

                    <Button className="w-full" onClick={() => setBookingStep("payment")}>
                      Continue to {bookingType === "buy" ? "Payment" : "Confirmation"}
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            </>
          )}

          {bookingStep === "payment" && (
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                    <CreditCard className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Payment Information</CardTitle>
                    <CardDescription>Enter your payment details</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="card" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-6">
                    <TabsTrigger value="card">Credit Card</TabsTrigger>
                    <TabsTrigger value="paypal">PayPal</TabsTrigger>
                    <TabsTrigger value="apple">Apple Pay</TabsTrigger>
                  </TabsList>
                  <TabsContent value="card">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="cardName">Name on Card</Label>
                        <Input id="cardName" placeholder="Enter name as it appears on card" />
                      </div>
                      <div>
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input id="cardNumber" placeholder="0000 0000 0000 0000" />
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="col-span-1">
                          <Label htmlFor="expMonth">Expiry Month</Label>
                          <Select>
                            <SelectTrigger id="expMonth">
                              <SelectValue placeholder="MM" />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: 12 }, (_, i) => (
                                <SelectItem key={i + 1} value={String(i + 1).padStart(2, "0")}>
                                  {String(i + 1).padStart(2, "0")}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-1">
                          <Label htmlFor="expYear">Expiry Year</Label>
                          <Select>
                            <SelectTrigger id="expYear">
                              <SelectValue placeholder="YY" />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: 10 }, (_, i) => (
                                <SelectItem key={i} value={String(new Date().getFullYear() + i).slice(-2)}>
                                  {String(new Date().getFullYear() + i).slice(-2)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-1">
                          <Label htmlFor="cvv">CVV</Label>
                          <Input id="cvv" placeholder="123" />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="billingAddress">Billing Address</Label>
                        <Input id="billingAddress" placeholder="Enter billing address" />
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="paypal">
                    <div className="text-center py-8">
                      <p className="mb-4">You will be redirected to PayPal to complete your payment.</p>
                      <Button>Continue to PayPal</Button>
                    </div>
                  </TabsContent>
                  <TabsContent value="apple">
                    <div className="text-center py-8">
                      <p className="mb-4">You will be redirected to Apple Pay to complete your payment.</p>
                      <Button>Continue to Apple Pay</Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter>
                <div className="w-full flex flex-col md:flex-row gap-4">
                  <Button variant="outline" className="flex-1" onClick={() => setBookingStep("details")}>
                    Back
                  </Button>
                  <Button className="flex-1" onClick={() => setBookingStep("confirmation")}>
                    Complete Payment
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )}

          {bookingStep === "confirmation" && (
            <Card className="mb-6">
              <CardHeader className="bg-primary/5 border-b">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-4">
                    <Check className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <CardTitle>Booking Confirmed</CardTitle>
                    <CardDescription>
                      Your {bookingType === "buy" ? "ticket has been purchased" : "seat has been blocked"}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="bg-muted/30 p-4 rounded-lg mb-6">
                  <p className="font-medium mb-2">Confirmation Number</p>
                  <p className="text-2xl font-bold">{bookingType === "buy" ? "CNF12345678" : "BLK87654321"}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {bookingType === "buy"
                      ? "Please save this number for future reference"
                      : "You must confirm this booking before May 1, 2024"}
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Passenger Information</h3>
                    <p>John Doe</p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="font-medium mb-2">Flight Information</h3>
                    <p>
                      {flight.airline} · Flight {flight.flightNumber}
                    </p>
                    <p>
                      {flight.origin} to {flight.destination}
                    </p>
                    <p>
                      {flight.departureDate} · {flight.departureTime} - {flight.arrivalTime}
                    </p>
                  </div>

                  {bookingType === "block" && (
                    <>
                      <Separator />
                      <div>
                        <h3 className="font-medium mb-2">Important Information</h3>
                        <p className="text-sm">
                          You have blocked this seat at no cost. You must confirm your booking before 2 weeks prior to
                          departure (May 1, 2024). If not confirmed, your booking will be automatically cancelled.
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <div className="w-full flex flex-col md:flex-row gap-4">
                  <Button variant="outline" className="flex-1" asChild>
                    <Link href="/">Return to Home</Link>
                  </Button>
                  <Button className="flex-1" asChild>
                    <Link href="/my-bookings">View My Bookings</Link>
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )}
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-6">
            <CardHeader>
              <CardTitle>Price Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Base fare (1 Adult)</span>
                  <span>${flight.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxes & Fees</span>
                  <span>$45.00</span>
                </div>
                <div className="flex justify-between">
                  <span>Service Fee</span>
                  <span>$15.00</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>${(flight.price + 45 + 15).toFixed(2)}</span>
                </div>

                {bookingType === "block" && (
                  <div className="bg-green-50 p-3 rounded-md mt-4">
                    <p className="text-green-700 text-sm">
                      <strong>No payment required now.</strong> You can block this seat at no cost and pay later when
                      you confirm.
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex-col items-start">
              <div className="w-full mb-4">
                <h3 className="font-medium mb-2">Cancellation Policy</h3>
                <div className="text-sm space-y-2">
                  <p>• Free cancellation up to 7 days before departure</p>
                  <p>• 50% refund between 7 days and 48 hours before departure</p>
                  <p>• No refund within 48 hours of departure</p>
                </div>
              </div>

              <div className="w-full">
                <h3 className="font-medium mb-2">Need Help?</h3>
                <p className="text-sm mb-2">Our customer service team is available 24/7</p>
                <Button variant="outline" className="w-full">
                  Contact Support
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
