import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function SpecialOffers() {
  return (
    <section className="container mx-auto py-16 px-4">
      <h2 className="text-3xl font-bold mb-2 text-center">Special Offers</h2>
      <p className="text-center text-muted-foreground mb-8">Exclusive deals for our customers</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="overflow-hidden">
          <div className="h-48 bg-[url('/placeholder.svg?height=400&width=600')] bg-cover bg-center"></div>
          <CardHeader>
            <CardTitle>Weekend Getaway</CardTitle>
            <CardDescription>30% off on selected destinations</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Escape for the weekend with our special discount on flights to popular destinations. Book by Friday for
              travel this weekend.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/offers/weekend">View Offer</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-48 bg-[url('/placeholder.svg?height=400&width=600')] bg-cover bg-center"></div>
          <CardHeader>
            <CardTitle>Family Package</CardTitle>
            <CardDescription>Kids fly free with two adults</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Plan your family vacation with our special family package. Children under 12 fly free when accompanied by
              two paying adults.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/offers/family">View Offer</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-48 bg-[url('/placeholder.svg?height=400&width=600')] bg-cover bg-center"></div>
          <CardHeader>
            <CardTitle>Business Class Upgrade</CardTitle>
            <CardDescription>50% off business class upgrades</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Enjoy the comfort of business class at a fraction of the cost. Upgrade your economy ticket to business
              class and save 50%.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/offers/upgrade">View Offer</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </section>
  )
}
