"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"

export function MainNav() {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="flex items-center">
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild className="lg:hidden">
          <Button variant="ghost" size="icon">
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left">
          <div className="grid gap-6 py-6">
            <Link href="/" className="flex items-center gap-2 text-lg font-semibold" onClick={() => setIsOpen(false)}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary"
              >
                <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"></path>
              </svg>
              <span>AirlineRS</span>
            </Link>
            <div className="grid grid-flow-row gap-2 text-sm">
              <Link
                href="/"
                className={cn(
                  "flex w-full items-center rounded-md p-2 hover:bg-accent",
                  pathname === "/" && "bg-accent",
                )}
                onClick={() => setIsOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/search"
                className={cn(
                  "flex w-full items-center rounded-md p-2 hover:bg-accent",
                  pathname === "/search" && "bg-accent",
                )}
                onClick={() => setIsOpen(false)}
              >
                Book Flight
              </Link>
              <Link
                href="/flight-status"
                className={cn(
                  "flex w-full items-center rounded-md p-2 hover:bg-accent",
                  pathname === "/flight-status" && "bg-accent",
                )}
                onClick={() => setIsOpen(false)}
              >
                Flight Status
              </Link>
              <Link
                href="/my-bookings"
                className={cn(
                  "flex w-full items-center rounded-md p-2 hover:bg-accent",
                  pathname === "/my-bookings" && "bg-accent",
                )}
                onClick={() => setIsOpen(false)}
              >
                My Bookings
              </Link>
              <Link
                href="/profile"
                className={cn(
                  "flex w-full items-center rounded-md p-2 hover:bg-accent",
                  pathname === "/profile" && "bg-accent",
                )}
                onClick={() => setIsOpen(false)}
              >
                My Profile
              </Link>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <NavigationMenu className="hidden lg:flex">
        <NavigationMenuList>
          <NavigationMenuItem>
            <Link href="/" legacyBehavior passHref>
              <NavigationMenuLink className={navigationMenuTriggerStyle()}>Home</NavigationMenuLink>
            </Link>
          </NavigationMenuItem>
          <NavigationMenuItem>
            <NavigationMenuTrigger>Book</NavigationMenuTrigger>
            <NavigationMenuContent>
              <ul className="grid gap-3 p-6 md:w-[400px] lg:w-[500px] lg:grid-cols-2">
                <li className="row-span-3">
                  <NavigationMenuLink asChild>
                    <a
                      className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-blue-500 to-blue-900 p-6 no-underline outline-none focus:shadow-md"
                      href="/search"
                    >
                      <div className="mt-4 mb-2 text-lg font-medium text-white">Book Your Next Adventure</div>
                      <p className="text-sm leading-tight text-white/90">Find the best flights at the best prices</p>
                    </a>
                  </NavigationMenuLink>
                </li>
                <li>
                  <Link href="/search" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">Flight Search</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        Search for flights to your destination
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
                <li>
                  <Link href="/special-offers" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">Special Offers</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        Exclusive deals and discounts
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
                <li>
                  <Link href="/destinations" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">Popular Destinations</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        Explore our most popular routes
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
              </ul>
            </NavigationMenuContent>
          </NavigationMenuItem>
          <NavigationMenuItem>
            <NavigationMenuTrigger>Manage</NavigationMenuTrigger>
            <NavigationMenuContent>
              <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                <li>
                  <Link href="/my-bookings" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">My Bookings</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        View and manage your flight reservations
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
                <li>
                  <Link href="/flight-status" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">Flight Status</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        Check the status of any flight
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
                <li>
                  <Link href="/check-in" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">Online Check-in</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        Check in for your flight online
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
                <li>
                  <Link href="/baggage" legacyBehavior passHref>
                    <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                      <div className="text-sm font-medium leading-none">Baggage Information</div>
                      <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                        Baggage allowance and fees
                      </p>
                    </NavigationMenuLink>
                  </Link>
                </li>
              </ul>
            </NavigationMenuContent>
          </NavigationMenuItem>
          <NavigationMenuItem>
            <Link href="/profile" legacyBehavior passHref>
              <NavigationMenuLink className={navigationMenuTriggerStyle()}>My Profile</NavigationMenuLink>
            </Link>
          </NavigationMenuItem>
        </NavigationMenuList>
      </NavigationMenu>
    </div>
  )
}
